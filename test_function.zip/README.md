# Experiments
## Currently working on AWS SDK projects
These projects include command line and automated tools for configuring and monitoring AWS infrastructure and network traffic.
## Future
* Planning on using vpc flow logs to map network traffic
